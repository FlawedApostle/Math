#pragma once
#include <math.h>
class Vec3 {
public:
	//float w;			// added 4D variable
	float x, y, z;
	float col1f = NULL;  
	float col2f = NULL; 
	float col3f = NULL; 
	float col4f = NULL;  
	float colf5 = NULL;
	float colf6 = NULL;

	int Col1minusCol2 = NULL;  
	int Col3minusCol4 = NULL;  
	int Col5minusCol6 = NULL;			// float
	
	// Print functions
	void print();
	void set(float x_, float y_, float z_);
	//void set(float x_, float y_, float z_ , float w_);

	
	// constructors
	Vec3();
	Vec3(float x, float y, float z);
	//Vec3(float x, float y, float z , float w_);
	Vec3(const Vec3& v);
	
	/// operators + , - , * , =
	const Vec3& operator + (const Vec3& v) const;
	Vec3& operator += (const Vec3& v);
	Vec3& operator = (const Vec3& v);
	// operators - 
	const Vec3& operator - (const Vec3& v) const;
	Vec3& operator -= (const Vec3& v);
	// operators *
	const Vec3& operator *(const Vec3& v);
	Vec3& operator *= (const Vec3& v);
	
	/// Distance between A Point and a Line || Q - S|| returns a Vector
	Vec3 Q_Minus_S(const Vec3& V, const Vec3& v) const;
	/// Distance between A Point and a Line || Q - S|| ^ 2	 returns a float
	float Q_Minus_S_Squared(const Vec3& V , const Vec3& v) const;


	/// cross product
	Vec3& CrossProductVec(Vec3& A, Vec3& B, double sinTheta);
	float CrossProduct(const Vec3& v, const Vec3& b, float theta);			    // Vec3& 
	Vec3&  CrossProduct_2(Vec3& v, Vec3& b, double theta);						// Vec3& 
	Vec3& CrossProduct_3(Vec3& x, Vec3& y);				// double theta			// float
	
	/// magnitude
	float Mag(float x_, float y_, float z_);									// up for removal
	float Mag();																// up for removal
	// My functions
	float Magnitude(float x_, float y_, float z_);
	float MagnitudeDistance(float x_, float y_, float z_);						// Finding Distance Between Point & A Line
	Vec3& MagnitudeVec(Vec3& vecA);												// Final
	
	/// normalize
	Vec3 Normalize(float x, float y, float z);
	Vec3 Normalize();
	float Normalize_Vec4(float  x_, float y_, float z_);

	/// dot product
	float DotProduct(Vec3& a , Vec3& b , float angle_theta);					/// Dot Product Using Angle Theta, 
	float DotProductDistance(Vec3& a, Vec3& b);									/// Dot Product No angle , Long Hand Format
	Vec3& DotProduct_2(Vec3& a, Vec3& b, float angle_theta);
	Vec3& DotProduct_3(Vec3& a, Vec3& b, float angle_theta);
	Vec3& DotProductVec(Vec3& vecA, Vec3& vecB, float cosTheta);


	/// Parametric
	// P(t) = S + tV
	// t >= 0
	//Vec3& t_infinity;
	//Vec3& v_direction;		// find mag for direction 
	float s_startingPoint;
	float parametric( Vec3 A, Vec3 B, float t);

	/// distance to from point to line
	// d = sqrt( ||Q - s||^2 - [(Q-S) . V]^2 / ||V||^2 )
	// Vec3 Q_arbitrary , Vec3 Point_Start , Vec3 Point_End
	float DistanceFromPointToLine(Vec3 Point_Start, Vec3 Point_End , Vec3 Q_arbitrary);


};


// Vec4
class Vec4 : public Vec3{
public:
	float x, y, z, w;
	void set(float x_, float y_, float z_, float w_);
	// constructors
	Vec4(const Vec4& v);
	Vec4();
	Vec4(float x, float y, float z, float w);
	
	// operators +
	/*
	const Vec4& operator + (const Vec4& v) const;
	Vec4& operator += (const Vec4& v);
	Vec4& operator = (const Vec4& v);
	// operators - 
	const Vec4& operator - (const Vec4& v) const;
	Vec4& operator -= (const Vec4& v);
	// operators *
	const Vec4& operator *(const Vec4& v);
	Vec4& operator *= (const Vec4& v);
	*/


};



// Ray class
class Ray
{
public:
	Vec3 vec3;		// class obj

	//float Sx, Sy, Sz, Dx, Dy, Dz;
	float startX, startY, startZ;
	float dirX, dirY, dirZ;
	Vec3 start;
	Vec3 dir;
	
	void Set(float x_, float y_, float z_, float x, float y, float z);
	void Set(float x_, float y_, float z_);
	void SetStart(float x_, float y_, float z_);
	void SetDir(float x_, float y_, float z_);

	// default
	Ray();
	Ray(const Vec3& s, const Vec3& d);
	void print();
};