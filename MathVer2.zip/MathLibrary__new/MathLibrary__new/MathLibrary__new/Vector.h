#pragma once
#include <math.h>
class Vec3 {
public:
	//float w;			// added 4D variable
	float x, y, z;
	float col1f = NULL;  
	float col2f = NULL; 
	float col3f = NULL; 
	float col4f = NULL;  
	float colf5 = NULL;
	float colf6 = NULL;

	int Col1minusCol2 = NULL;  
	int Col3minusCol4 = NULL;  
	int Col5minusCol6 = NULL;			// float
	
	void set(float x_, float y_, float z_);
	//void set(float x_, float y_, float z_ , float w_);
	// constructors
	Vec3();
	Vec3(float x, float y, float z);
	//Vec3(float x, float y, float z , float w_);
	Vec3(const Vec3& v);
	
	// operators +
	const Vec3& operator + (const Vec3& v) const;
	Vec3& operator += (const Vec3& v);
	Vec3& operator = (const Vec3& v);
	// operators - 
	const Vec3& operator - (const Vec3& v) const;
	Vec3& operator -= (const Vec3& v);
	// operators *
	const Vec3& operator *(const Vec3& v);
	Vec3& operator *= (const Vec3& v);

	// cross product
	Vec3& CrossProductVec(Vec3& A, Vec3& B, double sinTheta);
	float CrossProduct(const Vec3& v, const Vec3& b, float theta);			    // Vec3& 
	Vec3&  CrossProduct_2(Vec3& v, Vec3& b, double theta);						// Vec3& 
	Vec3& CrossProduct_3(Vec3& x, Vec3& y);				// double theta			// float
	
	// magnitude
	float Mag(float x_, float y_, float z_);
	float Mag();
	float Magnitude(float x_, float y_, float z_);
	Vec3& MagnitudeVec(Vec3& vecA);												/// Final
	// normalize
	Vec3 Normalize(float x, float y, float z);
	Vec3 Normalize();
	float Normalize_Vec4(float  x_, float y_, float z_);

	// dot product
	float DotProduct(Vec3& a , Vec3& b , float angle_theta);					// Vec3& 
	Vec3& DotProduct_2(Vec3& a, Vec3& b, float angle_theta);
	Vec3& DotProduct_3(Vec3& a, Vec3& b, float angle_theta);
	Vec3& DotProductVec(Vec3& vecA, Vec3& vecB, float cosTheta);


};


// Vec4
class Vec4 : public Vec3{
public:
	float x, y, z, w;
	void set(float x_, float y_, float z_, float w_);
	// constructors
	Vec4(const Vec4& v);
	Vec4();
	Vec4(float x, float y, float z, float w);
	
	// operators +
	/*
	const Vec4& operator + (const Vec4& v) const;
	Vec4& operator += (const Vec4& v);
	Vec4& operator = (const Vec4& v);
	// operators - 
	const Vec4& operator - (const Vec4& v) const;
	Vec4& operator -= (const Vec4& v);
	// operators *
	const Vec4& operator *(const Vec4& v);
	Vec4& operator *= (const Vec4& v);
	*/


};